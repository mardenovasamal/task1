import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        int[] arr = {10, 1, 32, 3, 45};
        int minVal = Utils.findMin(5, arr);
        System.out.println("Minimum value is: " + minVal);

        int avgVal = (int) Utils.findAverage(4, new int[]{3, 2, 4, 1});
        System.out.println("Average value is: " + avgVal);

        boolean isPrime = Utils.isPrime(7);
        System.out.println("Is prime: " + isPrime);

        int factorial = Utils.factorial(5);
        System.out.println("Factorial of 5 is: " + factorial);

        int fibonacci = Utils.fibonacci(5);
        System.out.println("Fibonacci number at index 5 is: " + fibonacci);

        int power = Utils.power(2, 10);
        System.out.println("2 raised to the power of 10 is: " + power);

        int[] arr2 = {1, 4, 6, 2};
        Utils.reverseArray(4, arr2);
        System.out.println("Reversed array: " + Arrays.toString(arr2));

        boolean isAllDigits = Utils.isAllDigits("123456");
        System.out.println("Is all digits: " + isAllDigits);

        int binomialCoefficient = Utils.binomialCoefficient(7, 2);
        System.out.println("Binomial coefficient is: " + binomialCoefficient);

        int gcd = Utils.gcd(32, 48);
        System.out.println("GCD of 32 and 48 is: " + gcd);
    }
}